package com.yrrhelp.services;
import com.yrrhelp.models.Product;
import com.yrrhelp.models.CartItems;
import com.yrrhelp.repository.CartItemsRepository;
import com.yrrhelp.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;


public class CartItemsService {
    @Autowired
    private ProductRepository productRepository;
            @Autowired
            private CartItemsRepository cartItemsRepository;
    public void addToCart(String id, CartItems cartItems, String firstname){

        Product product = productRepository.findById(id).orElse(null);
        cartItems.setProduct(product);

        cartItems.setSubtotal(product.getPrice());
        cartItems.setFirstname(firstname);

        cartItemsRepository.save(cartItems);


    }
    public List<CartItems> myCart(String firstname){

        List<CartItems> cartItems = new ArrayList<>();
       // cartItemsRepository.findByUsername(this.firstname).forEach(cartItems::add());

        return cartItems;
    }
}
