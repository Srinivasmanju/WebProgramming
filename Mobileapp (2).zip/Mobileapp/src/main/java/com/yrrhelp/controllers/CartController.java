package com.yrrhelp.controllers;

import com.yrrhelp.services.CartItemsService;
import com.yrrhelp.services.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class CartController {

    @GetMapping("/Cart")
    public String showCartPage() {

        System.out.println("Iteams in cart");

        return "Cart";
    }
    @RequestMapping("/done")
    public  String verfi(){
        return "OrderConf";
    }
    /*
    @PostMapping("/addToCart/{carId}")
    public String addToCart(@PathVariable String id, @ModelAttribute CartItems cartItems, Principal principal){

        //to save to cartItem table.
        CartItemsService.addToCarti(id, cartItems, principal.getName());

        return "product";
    }

    @GetMapping("product/Cart")
    public  String myCart ( @AuthenticationPrincipal Principal principal, Model model){

        List<CartItems> cartItems =  cartService.Cart(principal.getName());
        model.addAttribute("cartItems",cartItems);
        return "Cart";
    }


    @GetMapping("product/Cart")
    public String getAllProducts(Model model) {
        model.addAttribute("products",productService.getAllProducts());

        return "cart";
    } */
}