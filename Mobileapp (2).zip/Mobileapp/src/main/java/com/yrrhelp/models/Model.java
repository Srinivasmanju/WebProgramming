package com.yrrhelp.models;

import org.springframework.stereotype.Repository;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

@Repository
public class Model {
    Connection con;
    public void insert(Register register) throws ClassNotFoundException, SQLException {
        String addr = "jdbc:mysql://localhost:3306/shoeapp";
        String username= "root";
        String password= "root";
        Class.forName("com.mysql.cj.jdbc.Driver");
        con= DriverManager.getConnection(addr, username, password);
        String sql = "insert into register values (?,?,?,?);";
        PreparedStatement stmt = con.prepareStatement(sql);
        stmt.setString(3,register.emailid);
        stmt.setString(1,register.firstname);
        stmt.setString(4,register.password);
        stmt.setString(2,register.lastname);
        stmt.execute();
        System.out.println("Records inserted succesfully");


        con.close();
    }
}
