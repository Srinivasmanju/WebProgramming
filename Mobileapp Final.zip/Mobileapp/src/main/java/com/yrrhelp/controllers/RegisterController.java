package com.yrrhelp.controllers;

import com.yrrhelp.models.Model;

import com.yrrhelp.models.Register;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.http.HttpStatus;

import java.sql.SQLException;
import org.springframework.http.HttpStatus;

import javax.validation.Valid;


@Controller
public class RegisterController {
    @Autowired
    Model model ;
    @GetMapping("/Register")
    public String showRegisterPage() {


        return "Register";
    }
    @RequestMapping("/save")
    public String save(@ModelAttribute("register") Register register) throws ClassNotFoundException, SQLException {
        System.out.println(register.emailid);
        System.out.println(register.firstname);
        System.out.println(register.lastname);
        System.out.println(register.password);

        model.insert(register);
        return "complete";

    }


}
