<?php
session_start();
if(isset($_POST['save']))
{
    extract($_POST);
    $servername="localhost:3306/shoeapp?useSSL=false";
    $username= "root";
    $password= "root";
    $sql=mysqli_query($conn,"SELECT * FROM register where emailid='$emailid' and password='$password'");
    $row  = mysqli_fetch_array($sql);
    if(is_array($row))
    {

        $_SESSION["firstname"]=$row['firstname'];
        $_SESSION["lastname"]=$row['lastname'];
         $_SESSION["emailid"]=$row['emailid'];
         $_SESSION["password"] = $row['password'];


        header("Location: home.jsp");
    }
    else
    {
        echo "Invalid Email ID/Password";
    }
}
?>